package test;

/*
    1번 문제
    - 기본 데이터 타입은 객체의 데이터 타입을 나타낸다
      정수형에는 int, 문자에는 char 등이 있다

    - 참조 데이터타입은 객체 주소를 나타내는 자료의 데이터 타입을 나타낸다
      정수형에는 Integer, 문자에는 Charater 등이 있다
 */


// 6번 문제
// : Object 클래스

// 7번 문제
// :

// 8번 문제
// : 삼항 연산자

// 9번 문제
// : private 메서드

// 10번 문제
// : 2. 반드시 하나의 추상 메서드를 포함

// 11번 문제
// : Parent

// 12번 문제
// : 2. private static

// 13번 문제
// : 예

// 14번 문제
// :

// 15번 문제
// : 2. 복잡한 생성자 호출을 피할 수 있다

// 16번 문제
// : 3. Controller

// 17번 문제
// : default

// 18번 문제
// : 3. 인터페이스는 필드를 가질 수 없다

// 19번
// : 용어 확립, 개념 확립 이해도가 애매하여 코드가 길어지면 눈에 안 들어옵니다
//



// 20번
// : 개념정리 잘 해주셔서 입문에 도움이 됩니다. 학원의 다른 강의를 듣는다면 이승아 강사님의 수업을 원합니다.
//   지금은 코드도 길고 사용해야할 개념들도 많아서 할 수 없겠지만,
//   컬렉션프레임워크 전까지는 학생들이 스스로 코드를 짜보도록 문제를 던져주고 5~10분 시간을 주셨으면 합니다.
//   하루 수업시간이 길다보니 스스로 코드를 짜면서 생각을 정리할 시간을 원합니다.

class Student {
    private String name; // 이름
    private int score;   // 점수

    // 생성자
    public Student(String name, int score) {
        this.name = name;
        this.score = score;
    }

    // 이름을 반환하는 메서드
    public String getName() {
        return name;
    }

    // 점수를 반환하는 메서드
    public int getScore() {
        return score;
    }
}

public class Test {
    public static void main(String[] args) {
        // 2번 문제
        int num1 = 10;
        int double num2 = 3.5;
        double result = (double)num1 + num2;


        // 3번 문제
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        if(num % 2 == 0) {
            System.out.println("입력하신 숫자는 짝수입니다");
        } else {
            System.out.println("입력하신 숫자는 홀수입니다");
        }


        // 4번 문제
        for(int number : numbers){
            System.out.println(number);
        }


        // 5번 문제
        // : class Test 바로 위에 클래스를 작성하고 main 메서드 내부에서 객체를 생성하세요.


        // 1. Student 객체 배열 생성 및 초기화
        Student[] students = {
                new Student("이승아", 85),
                new Student("이도경", 92),
                new Student("이지희", 78),
                new Student("이지훈", 88),
                new Student("김명진", 95)
        };

        // 2. 점수가 90점 이상인 학생의 이름 출력
        System.out.println("90점 이상인 학생:");
        for (Student student : students) {
            if (student.getScore() >= 90) {
                System.out.println(student.getName());
            }
        }




    }
}
