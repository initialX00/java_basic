public class Test {
	public static void main(String[] args) {
		int a, b = 10;
		a = 20 % 11 / 3 * 5 - b;
		System.out.printf("%d\n", a);
	}
}