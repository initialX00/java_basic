i, hap = 0, 0
while 1:
    i += 1
    hap += i
    if i >= 100:
        break
print(hap)