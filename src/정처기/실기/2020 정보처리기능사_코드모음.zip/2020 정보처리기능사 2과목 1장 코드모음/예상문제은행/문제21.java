public class Test {
	public static void main(String[] args){
		String str;
		str = "Power overwhelming!";
		System.out.printf("%8.4s\n", str);
	}
}