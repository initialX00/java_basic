#include <stdio.h>

main()
{
	int j = 024, k = 24, L = 0x24, hap;
	hap = j + k + L;
	printf("%d, %d, %d, %d\n", j, k, L, hap);
}