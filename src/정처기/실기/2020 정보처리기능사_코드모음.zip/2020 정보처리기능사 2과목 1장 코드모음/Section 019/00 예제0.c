#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

main()
{
	int i, j, k;
	scanf("%d %d", &i, &j);
	k = i + j;
	printf("%d\n", k);
}