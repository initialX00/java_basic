#include <stdio.h>
#define K 5
int main()
{
	int n = 0, b[K] = { 1, 0, 1, 1, 0 }, i, j, temp;
	for (i = 0; i < K; i++)
	{
		temp = 1;
		for (
			j = 1; j <= K - 1 - i; j++)
			temp *= 2;
		n = n + b[i] * temp;
	}
	printf("%d", n);
	return 0;
}