#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
main() {
	int a, b, sum;
	scanf("%d %d", &a, &b);
	sum = a + b;
	printf("%d", sum);
}