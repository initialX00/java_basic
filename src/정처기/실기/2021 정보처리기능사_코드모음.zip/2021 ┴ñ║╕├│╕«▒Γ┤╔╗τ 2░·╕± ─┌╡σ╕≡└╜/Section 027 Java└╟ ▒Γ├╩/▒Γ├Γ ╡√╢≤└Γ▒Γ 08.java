public class Test {
	public static void main(String[] args) {
		int p = 0, i = 0;
		do {
			i++;
			if (i % 3 == 0)
				p += i;
		} while(i < 10);
		System.out.print(p);
	}
}