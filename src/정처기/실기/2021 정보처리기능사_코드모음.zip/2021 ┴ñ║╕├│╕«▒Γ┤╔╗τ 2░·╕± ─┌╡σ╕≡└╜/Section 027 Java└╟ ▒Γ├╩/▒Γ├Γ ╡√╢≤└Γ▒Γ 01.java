public class Test {
	public static void main(String[] args) {
		String str = "HRDK" + 40 + 23;
		System.out.println(str);
	}
}