#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
main() {
	char str[128];
	scanf("%s", str);
	printf("%s", str);
}