main() /* 2017.2.10 by Kang*/
{
	int abc_1;
	int 1abc;
	int Kim;
	int kim;
	int for;
	char kang
}