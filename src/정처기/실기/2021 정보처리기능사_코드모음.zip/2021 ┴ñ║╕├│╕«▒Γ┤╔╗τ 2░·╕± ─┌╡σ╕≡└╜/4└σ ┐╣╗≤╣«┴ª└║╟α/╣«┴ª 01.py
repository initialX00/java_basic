class Employee:
    name = 'ȫ�浿'
    idNum = 17001
    salary = 4500000
    sex = True
a = Employee()
print(a.name)
print(a.idNum)
print(a.salary)
print(a.sex)