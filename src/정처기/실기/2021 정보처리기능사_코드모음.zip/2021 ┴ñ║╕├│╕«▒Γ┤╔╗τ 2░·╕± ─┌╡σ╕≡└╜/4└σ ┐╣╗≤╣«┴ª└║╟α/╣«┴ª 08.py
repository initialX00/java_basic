i, hap = 0, 0
while True
    i += 1
    hap += i
    if i >= 100:
        break
print(hap)