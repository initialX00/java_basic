i, hap = 0, 0
while i < 5:
	i += 1
	hap += i
print(hap)