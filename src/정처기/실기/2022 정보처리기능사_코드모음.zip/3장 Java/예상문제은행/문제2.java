public class Problem {
	public static void main(String[] args) {
		int a = 035, b = 0x35, c = 35;
		System.out.printf("%d\n", a);
		System.out.printf("%d\n", b);
		System.out.printf("%d\n", c);
	}
}