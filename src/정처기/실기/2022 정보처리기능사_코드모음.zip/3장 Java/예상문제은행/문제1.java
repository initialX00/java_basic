public class Problem {
	public static void main(String[] args) {
		byte a = 15, b = 19;
		System.out.printf("%d\n", ~a);
		System.out.printf("%d\n", a^b);
		System.out.printf("%d\n", a&b);
		System.out.printf("%d\n", a|b);
	}
}