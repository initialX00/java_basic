public class Test {
	public static void main(String[] args) {
		int i, n = 25;
		for (i = 1; i <= n; i++)
			if (n % i == 0)
				System.out.print(i);
	}
}