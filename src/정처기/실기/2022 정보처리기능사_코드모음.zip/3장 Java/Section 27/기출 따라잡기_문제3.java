public class Test {
	public static void main(String[] args) {
		int a = 9;
		int b = 11;
		int c = a^b;
		System.out.println(c);
	}
}