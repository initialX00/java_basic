public class Test {
	public static void main(String[] args) {
		char num = 0x06;
		System.out.printf("%04x", num << 2);
	}
}