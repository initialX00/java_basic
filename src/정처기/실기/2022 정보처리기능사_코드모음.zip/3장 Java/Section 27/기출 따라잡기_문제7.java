public class Test {
	public static void main(String[] args) {
		int n = 10;
		name(n);
		System.out.println(n);
	}
	public static void name(int n) {
		n = n + 1;
	}
}