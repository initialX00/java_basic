public class Test {
	public static void main(String[] args) {
		int arr[] = { 0,1,2,3 };
		for (int num:arr)
			System.out.println(num);
	}
}