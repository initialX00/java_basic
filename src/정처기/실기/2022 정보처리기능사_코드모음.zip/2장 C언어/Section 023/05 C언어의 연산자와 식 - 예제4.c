#include <stdio.h>
main()
{
	int a = 2, b = 3, c = 4;
	a += 2;
	b *= 2;
	c %= 2;
	printf("%d, %d, %d\n", a, b, c);
}