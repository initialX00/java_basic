main()
{
	A = 3; 
	A = 5 + 3;
	A = A + 5; 
}