main()
{
	char aa = 'A'; 
	char ab[6] = "KOREA"; 
	short int si = 32768; 
	int in = 32768;
	float fl = 24.56f; 
	double dfl = 24.5678; 
}