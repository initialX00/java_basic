#include <stdio.h>
main() {
	int a, b, result;
	a = 7, b = 4;
	result = a & b;
	printf("%d", result);
}