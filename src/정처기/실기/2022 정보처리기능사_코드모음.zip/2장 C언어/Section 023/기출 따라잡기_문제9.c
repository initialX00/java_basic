#include <stdio.h>
main()
{
	int a, b, r;
	scanf("%d %d", &a, &b);
	r = a % b;
	printf("%d", r);
}