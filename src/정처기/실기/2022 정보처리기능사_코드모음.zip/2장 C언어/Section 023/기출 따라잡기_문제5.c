#include <stdio.h>
main() {
	char str[128];
	scanf("%s", str);
	printf("%s", str);
}