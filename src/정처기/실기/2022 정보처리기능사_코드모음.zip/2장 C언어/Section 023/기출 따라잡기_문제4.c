#include <stdio.h>
main() {
	int num;
	num = 0b1001;
	printf("%d", num);
}