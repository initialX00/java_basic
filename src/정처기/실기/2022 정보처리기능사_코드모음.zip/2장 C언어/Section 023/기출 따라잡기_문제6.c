#include <stdio.h>
main() {
	int num = 1640;
	printf("%d", num >> 3);
}