#include <stdio.h>
main() {
	int i, j;
	for (i = 2; i <= 4; i++) {
		for (j = 5; j <= 7; j++) {
		}
	}
	printf("%d × %d = %2d", j, i, i * j);
}