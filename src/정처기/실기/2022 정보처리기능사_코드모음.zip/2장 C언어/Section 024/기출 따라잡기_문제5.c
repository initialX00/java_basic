#include <stdio.h>
#define func1 0
#define func2 1
main() {
	int num = 83;
	if (num % 2 == func1)
		printf("HRD");
	else if (num % 2 == func2)
		printf("KOREA");
	else
		printf("1644 - 8000");
}