#include <stdio.h>
main() {
	int c = 0, d, b[10];
	scanf("%d", &d);
	do {
		b[c] = d % 2;
		c++;
		d /= 2;
	} while (d != 0);
	while ((c > 0)) {
		c--;
		printf("%d", b[c]);
	}
}